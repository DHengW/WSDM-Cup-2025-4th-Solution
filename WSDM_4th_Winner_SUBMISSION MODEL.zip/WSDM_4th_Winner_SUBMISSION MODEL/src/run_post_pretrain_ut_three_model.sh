#!/bin/bash
set -e


qwen_path=../model_path/qwen2

sh run_post_pretrain-gen.sh qwen2 ${qwen_path}






