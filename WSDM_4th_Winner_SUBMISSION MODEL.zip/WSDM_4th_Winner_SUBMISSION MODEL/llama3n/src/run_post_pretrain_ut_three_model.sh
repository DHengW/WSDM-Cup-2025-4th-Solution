#!/bin/bash
set -e


llama_path=../model_path/Llama3N

sh run_post_pretrain-gen-athene.sh llama3n ${llama_path}






