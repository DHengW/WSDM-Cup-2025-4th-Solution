#模型下载
from modelscope import snapshot_download
model_dir = snapshot_download('Nexusflow/Athene-V2-Chat',local_dir='/root/autodl-tmp/src/4th_solution/athene/model_path/athene')